package com.example.madassignment2

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.AppCompatButton

class selection : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_selection)

        // Window insets handling removed to prevent null pointer exception

        val nextButton = findViewById<AppCompatButton>(R.id.loginButton)
        nextButton?.setOnClickListener {
            val intent = Intent(this, login::class.java)
            startActivity(intent)
        }

        val nextButton2 = findViewById<AppCompatButton>(R.id.signUpButton)
        nextButton2?.setOnClickListener {
            val intent = Intent(this, signup::class.java)
            startActivity(intent)
        }
    }
}