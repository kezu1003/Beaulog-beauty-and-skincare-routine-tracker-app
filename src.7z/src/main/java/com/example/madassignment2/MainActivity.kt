package com.example.madassignment2

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.AppCompatButton

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Set up Get Started button click listener
        val getStartedButton = findViewById<AppCompatButton>(R.id.getStartedButton)
        getStartedButton?.setOnClickListener {
            val intent = Intent(this, selection::class.java)
            startActivity(intent)
            finish() // Close MainActivity so user can't go back
        }
    }
}
